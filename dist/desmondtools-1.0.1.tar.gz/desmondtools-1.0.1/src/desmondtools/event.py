import os
import sys
import argparse
import random
import re

import desmondtools
from desmondtools import Multisim


def read_eaf(filename, verbose=False):
    HBond = {}
    Hydrophobic = {}
    WaterBridge = {}
    Polar = {}
    HalogenBond = {}
    LigWat = {}
    Metal = {}
    PiCat = {}
    PiPi = {}

    result = Multisim.expr.parse_file(filename)
    d = result.as_dict()
    Multisim.traverse_dict(d)
    dot = desmondtools.DotMap(d)

    for section in dot.Keywords:
        try:
            assert section.ProtLigInter.HBondResult
            num_frames = len(section.ProtLigInter.HBondResult)
            for frame in section.ProtLigInter.HBondResult:
                # [[3 "_:ARG_143:HH22" d-s "L-FRAG_0:N6" ]]
                for (frameno, prot, hbond_type, lig) in frame:
                    prot = prot.strip('\"')
                    (_, resid, atom) = prot.split(":")
                    (resName, resSeq) = resid.split("_")
                    resSeq = int(resSeq)
                    if resSeq in HBond:
                        HBond[resSeq]['count'] += 1
                    else:
                        HBond[resSeq] = {'resName': resName, 'count':1 }
            for resSeq in sorted(HBond):
                fraction = float(HBond[resSeq]['count'])/num_frames
                if verbose:
                    print(f"HBond {HBond[resSeq]['resName']}_{resSeq} {fraction:5.3f} {num_frames}")
        except:
            pass

        try:
            assert section.ProtLigInter.HydrophobicResult
            num_frames = len(section.ProtLigInter.HydrophobicResult)
            for frame in section.ProtLigInter.HydrophobicResult:
                # [[0 "_:PHE_223" L-FRAG_0 ] [0 "_:ALA_241" L-FRAG_0 ]]
                for (frameno, prot, lig) in frame:
                    prot = prot.strip('\"')
                    (_, resid) = prot.split(":")
                    (resName, resSeq) = resid.split("_")
                    resSeq = int(resSeq)
                    if resSeq in Hydrophobic:
                        Hydrophobic[resSeq]['count'] += 1
                    else:
                        Hydrophobic[resSeq] = {'resName': resName, 'count':1 }
            for resSeq in sorted(Hydrophobic):
                fraction = float(Hydrophobic[resSeq]['count'])/num_frames
                if verbose:
                    print(f"Hydrophobic {Hydrophobic[resSeq]['resName']}_{resSeq} {fraction:5.3f} {num_frames}")
        except:
            pass
        
        try:
            assert section.ProtLigInter.PolarResult
            num_frames = len(section.ProtLigInter.PolarResult)
            for frame in section.ProtLigInter.PolarResult:
                # [[1 "_:GLU_216:OE2" b "L-FRAG_1:N3" 4.45 ]]
                for (frameno, prot, _, lig, _) in frame:
                    prot = prot.strip('\"')
                    (_, resid, atom) = prot.split(":")
                    (resName, resSeq) = resid.split("_")
                    resSeq = int(resSeq)
                    if resSeq in Polar:
                        Polar[resSeq]['count'] += 1
                    else:
                        Polar[resSeq] = {'resName': resName, 'count':1 }
            for resSeq in sorted(Polar):
                fraction = float(Polar[resSeq]['count'])/num_frames
                if verbose:
                    print(f"Polar {Polar[resSeq]['resName']}_{resSeq} {fraction:5.3f} {num_frames}")
        except:
            pass

        try:
            assert section.ProtLigInter.WaterBridgeResult
            num_frames = len(section.ProtLigInter.WaterBridgeResult)
            for frame in section.ProtLigInter.WaterBridgeResult:
                # [[3 "_:GLU_216:OE2" a "L-FRAG_0:N2" a 2431 ]]
                for (frameno, prot, _, lig, _, _) in frame:
                    prot = prot.strip('\"')
                    (_, resid, atom) = prot.split(":")
                    (resName, resSeq) = resid.split("_")
                    resSeq = int(resSeq)
                    if resSeq in WaterBridge:
                        WaterBridge[resSeq]['count'] += 1
                    else:
                        WaterBridge[resSeq] = {'resName': resName, 'count':1 }
            for resSeq in sorted(WaterBridge):
                fraction = float(WaterBridge[resSeq]['count'])/num_frames
                if verbose:
                    print(f"WaterBridge {WaterBridge[resSeq]['resName']}_{resSeq} {fraction:5.3f} {num_frames}")
        except:
            pass

    return num_frames, HBond, Hydrophobic, Polar, WaterBridge, HalogenBond, LigWat, Metal, PiCat, PiPi